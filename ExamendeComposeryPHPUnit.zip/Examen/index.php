<?php

require ("vendor/autoload.php");

$conversion = new \temperatura\modelo\ConversorTemperaturas();

echo "5 ºC son ".$conversion->CelsiusToFarenheit(5)." ºF";
echo "<br>";
echo "10 ºF son ".$conversion->FarenheitToCelsius(10)." ºC";