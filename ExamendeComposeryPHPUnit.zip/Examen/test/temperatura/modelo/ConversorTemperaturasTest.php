<?php


namespace temperatura\modelo;


use PHPUnit\Framework\Error\Error;

class ConversorTemperaturasTest extends \PHPUnit\Framework\TestCase
{
    public function testconver1(){
        $conversion = new ConversorTemperaturas();
        $resultado = $conversion->CelsiusToFarenheit(0);
        $this->assertEquals(32, $resultado);
    }

    public function testconver2(){
        $conversion = new ConversorTemperaturas();
        $resultado = $conversion->CelsiusToFarenheit(50);
        $this->assertEquals(122, $resultado);
    }

    public function testconver3(){
        $conversion = new ConversorTemperaturas();
        $resultado = $conversion->CelsiusToFarenheit(500);
        $this->assertEquals(932, $resultado);
    }

    public function testconver4(){
        $conversion = new ConversorTemperaturas();
        $resultado = $conversion->CelsiusToFarenheit(501);
        $this->assertEquals(PHP_FLOAT_MAX, $resultado);
    }

    public function testconver5(){
        $conversion = new ConversorTemperaturas();
        $resultado = $conversion->FarenheitToCelsius(0);
        $this->assertEquals(-17.77, bcdiv($resultado,1,2));
    }

    public function testconver6(){
        $conversion = new ConversorTemperaturas();
        $resultado = $conversion->FarenheitToCelsius(200);
        $this->assertEquals(93.33, bcdiv($resultado,1,2));
    }

    public function testconver7(){
        $conversion = new ConversorTemperaturas();
        $resultado = $conversion->FarenheitToCelsius(600);
        $this->assertEquals(315, bcdiv($resultado,1,0));
    }

    public function testconver8(){
        $conversion = new ConversorTemperaturas();
        $resultado = $conversion->FarenheitToCelsius(932);
        $this->assertEquals(500, $resultado);
    }
}