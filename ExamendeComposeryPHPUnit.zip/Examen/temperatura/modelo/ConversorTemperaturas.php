<?php


namespace temperatura\modelo;


class ConversorTemperaturas
{
    public function CelsiusToFarenheit($a){
        if ($a > 500) {
            return PHP_FLOAT_MAX;
        } else {
            return ($a * 9 / 5) + 32;
        }
    }

    public function FarenheitToCelsius($a){
        if ($a > 932) {
            return PHP_FLOAT_MAX;
        } else {
            return ($a - 32) * 5 / 9;
        }
    }
}